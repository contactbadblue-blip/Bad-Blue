// API Routes - Badge Check
import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import multer from "multer";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { analyzeBadgeImage, lookupOfficerInfo } from "./openai";
import { 
  insertComplaintSchema,
  insertLawsuitFilingSchema,
  PRICING_CENTS
} from "@shared/schema";

// Stripe setup - from javascript_stripe blueprint
// Lazy initialization to avoid startup errors when API key is not configured
let stripe: Stripe | null = null;

function getStripeClient(): Stripe {
  if (!stripe) {
    if (!process.env.STRIPE_SECRET_KEY) {
      throw new Error('STRIPE_SECRET_KEY environment variable is not set');
    }
    stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2025-09-30.clover",
    });
  }
  return stripe;
}

// Multer setup for file uploads (in-memory)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Determines the appropriate submission venue for a complaint or lawsuit
 * based on jurisdiction and incident type
 */
function determineSubmissionVenue(state: string, city: string | null, county: string | null, incidentType: string): string {
  // For serious crimes like assault or excessive force, route to City Attorney and Internal Affairs
  const seriousViolations = ['assault', 'excessive-force', 'misconduct'];
  
  if (seriousViolations.includes(incidentType)) {
    if (city) {
      return `Internal Affairs (${city} Police Department), ${city} City Attorney`;
    }
    if (county) {
      return `County Sheriff Internal Affairs, ${county} County Attorney`;
    }
    return `State Police Internal Affairs, ${state} Attorney General`;
  }
  
  // For discrimination and harassment, route to Police Chief and County Sheriff
  if (incidentType === 'discrimination' || incidentType === 'harassment') {
    if (city) {
      return `${city} Police Chief, Internal Affairs`;
    }
    if (county) {
      return `${county} County Sheriff`;
    }
    return `${state} State Police`;
  }
  
  // Default routing for other types (negligence, etc.)
  if (city) {
    return `Internal Affairs (${city} Police Department)`;
  }
  if (county) {
    return `${county} County Sheriff`;
  }
  return `${state} State Police`;
}

/**
 * Normalizes state code (e.g., "CA", "NY") to full lowercase name for statute lookup
 */
function normalizeStateName(stateCode: string): string {
  const stateMap: Record<string, string> = {
    'AL': 'alabama', 'AK': 'alaska', 'AZ': 'arizona', 'AR': 'arkansas',
    'CA': 'california', 'CO': 'colorado', 'CT': 'connecticut', 'DE': 'delaware',
    'FL': 'florida', 'GA': 'georgia', 'HI': 'hawaii', 'ID': 'idaho',
    'IL': 'illinois', 'IN': 'indiana', 'IA': 'iowa', 'KS': 'kansas',
    'KY': 'kentucky', 'LA': 'louisiana', 'ME': 'maine', 'MD': 'maryland',
    'MA': 'massachusetts', 'MI': 'michigan', 'MN': 'minnesota', 'MS': 'mississippi',
    'MO': 'missouri', 'MT': 'montana', 'NE': 'nebraska', 'NV': 'nevada',
    'NH': 'new_hampshire', 'NJ': 'new_jersey', 'NM': 'new_mexico', 'NY': 'new_york',
    'NC': 'north_carolina', 'ND': 'north_dakota', 'OH': 'ohio', 'OK': 'oklahoma',
    'OR': 'oregon', 'PA': 'pennsylvania', 'RI': 'rhode_island', 'SC': 'south_carolina',
    'SD': 'south_dakota', 'TN': 'tennessee', 'TX': 'texas', 'UT': 'utah',
    'VT': 'vermont', 'VA': 'virginia', 'WA': 'washington', 'WV': 'west_virginia',
    'WI': 'wisconsin', 'WY': 'wyoming'
  };
  
  // Handle both full names and codes
  const normalized = stateCode.toUpperCase();
  return stateMap[normalized] || stateCode.toLowerCase().replace(/\s+/g, '_');
}

/**
 * Returns relevant state statutes and codes for lawsuits
 */
function getStateStatutes(state: string, lawsuitType: string): { statutes: string[], description: string} {
  // Normalize lawsuit type from kebab-case to snake_case for lookup
  const normalizedType = lawsuitType.replace(/-/g, '_');
  
  // This is a simplified version - in production, this would be a comprehensive database
  const stateStatutes: Record<string, Record<string, { statutes: string[], description: string }>> = {
    'california': {
      'assault': {
        statutes: ['Cal. Pen. Code § 242', 'Cal. Pen. Code § 243', '42 U.S.C. § 1983'],
        description: 'Battery by peace officer, civil rights violation'
      },
      'excessive_force': {
        statutes: ['Cal. Pen. Code § 149', '42 U.S.C. § 1983', 'Fourth Amendment'],
        description: 'Assault by public officer, federal civil rights claim'
      },
      'discrimination': {
        statutes: ['Cal. Gov. Code § 12940', '42 U.S.C. § 1983'],
        description: 'Employment discrimination, civil rights violation'
      },
      'harassment': {
        statutes: ['Cal. Pen. Code § 422', '42 U.S.C. § 1983'],
        description: 'Criminal threats, civil rights violation'
      },
      'misconduct': {
        statutes: ['Cal. Gov. Code § 815.2', '42 U.S.C. § 1983'],
        description: 'Public entity liability for employee acts'
      },
      'negligence': {
        statutes: ['Cal. Gov. Code § 815.2', 'Cal. Gov. Code § 820'],
        description: 'Liability of public entities and employees for injury'
      }
    },
    'new_york': {
      'assault': {
        statutes: ['N.Y. Pen. Law § 120.00', '42 U.S.C. § 1983'],
        description: 'Assault charges, federal civil rights violation'
      },
      'excessive_force': {
        statutes: ['N.Y. Pen. Law § 120.05', '42 U.S.C. § 1983', 'Fourth Amendment'],
        description: 'Assault in the second degree, civil rights claim'
      },
      'discrimination': {
        statutes: ['N.Y. Exec. Law § 296', '42 U.S.C. § 1983'],
        description: 'Unlawful discriminatory practices'
      },
      'harassment': {
        statutes: ['N.Y. Pen. Law § 240.26', '42 U.S.C. § 1983'],
        description: 'Harassment in the second degree'
      },
      'misconduct': {
        statutes: ['N.Y. Gen. Mun. Law § 50-i', '42 U.S.C. § 1983'],
        description: 'Notice of claim against municipality'
      },
      'negligence': {
        statutes: ['N.Y. Gen. Mun. Law § 50-e', 'N.Y. Court of Claims Act § 10'],
        description: 'Notice of claim for negligence'
      }
    },
    'texas': {
      'assault': {
        statutes: ['Tex. Pen. Code § 22.01', '42 U.S.C. § 1983'],
        description: 'Assault by public servant, civil rights violation'
      },
      'excessive_force': {
        statutes: ['Tex. Pen. Code § 22.02', '42 U.S.C. § 1983', 'Fourth Amendment'],
        description: 'Aggravated assault by public servant'
      },
      'discrimination': {
        statutes: ['Tex. Lab. Code § 21.051', '42 U.S.C. § 1983'],
        description: 'Employment discrimination'
      },
      'harassment': {
        statutes: ['Tex. Pen. Code § 42.07', '42 U.S.C. § 1983'],
        description: 'Harassment by public servant'
      },
      'misconduct': {
        statutes: ['Tex. Civ. Prac. & Rem. Code § 101.021', '42 U.S.C. § 1983'],
        description: 'Governmental liability'
      },
      'negligence': {
        statutes: ['Tex. Civ. Prac. & Rem. Code § 101.021'],
        description: 'Liability of governmental units'
      }
    }
  };

  // Default federal statutes for states not specifically listed
  const defaultStatutes: Record<string, { statutes: string[], description: string }> = {
    'assault': {
      statutes: ['42 U.S.C. § 1983', '18 U.S.C. § 242'],
      description: 'Civil rights violation, deprivation of rights under color of law'
    },
    'excessive_force': {
      statutes: ['42 U.S.C. § 1983', 'Fourth Amendment', '18 U.S.C. § 242'],
      description: 'Federal civil rights claim, unreasonable seizure'
    },
    'discrimination': {
      statutes: ['42 U.S.C. § 1983', '42 U.S.C. § 2000e'],
      description: 'Civil rights violation, employment discrimination'
    },
    'harassment': {
      statutes: ['42 U.S.C. § 1983', '18 U.S.C. § 242'],
      description: 'Civil rights violation, criminal deprivation of rights'
    },
    'misconduct': {
      statutes: ['42 U.S.C. § 1983', '18 U.S.C. § 242'],
      description: 'Civil rights violation for official misconduct'
    },
    'negligence': {
      statutes: ['42 U.S.C. § 1983', 'Federal Tort Claims Act'],
      description: 'Civil rights claim, federal tort liability'
    }
  };

  const normalizedState = normalizeStateName(state);
  const stateData = stateStatutes[normalizedState];
  
  if (stateData && stateData[normalizedType]) {
    return stateData[normalizedType];
  }
  
  return defaultStatutes[normalizedType] || defaultStatutes['misconduct'];
}

/**
 * Generates a lawsuit document with state-specific templates
 */
function generateLawsuitDocument(
  state: string,
  lawsuitType: string,
  officerName: string | null,
  officerBadge: string | null,
  officerDepartment: string | null,
  incidentDescription: string | null,
  incidentDate: Date,
  city: string | null,
  county: string | null
): string {
  const { statutes, description } = getStateStatutes(state, lawsuitType);
  const venue = determineSubmissionVenue(state, city, county, lawsuitType);
  
  const dateStr = incidentDate.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return `
CIVIL COMPLAINT FOR DAMAGES AND INJUNCTIVE RELIEF

Case Type: ${lawsuitType.replace(/_/g, ' ').toUpperCase()}
Jurisdiction: ${state}
${city ? `City: ${city}` : ''}
${county ? `County: ${county}` : ''}

PARTIES:
Plaintiff: [Your Name]
Defendant: ${officerName || 'Officer Name Unknown'}${officerBadge ? `, Badge #${officerBadge}` : ''}
${officerDepartment ? `Department: ${officerDepartment}` : ''}

JURISDICTION AND VENUE:
This complaint is filed pursuant to the following statutes:
${statutes.map(s => `• ${s}`).join('\n')}

Legal Basis: ${description}

Proper Venue: ${venue}

STATEMENT OF FACTS:
On ${dateStr}, the following incident occurred:

${incidentDescription || 'Incident details to be provided'}

CLAIMS FOR RELIEF:
1. Violation of civil rights under 42 U.S.C. § 1983
2. ${lawsuitType === 'assault' ? 'Assault and Battery' : ''}
${lawsuitType === 'excessive_force' ? 'Excessive Force in violation of the Fourth Amendment' : ''}
${lawsuitType === 'discrimination' ? 'Unlawful Discrimination' : ''}
${lawsuitType === 'harassment' ? 'Harassment and Intimidation' : ''}
${lawsuitType === 'misconduct' ? 'Official Misconduct and Abuse of Authority' : ''}
${lawsuitType === 'negligence' ? 'Negligence and Failure to Protect' : ''}
3. Intentional infliction of emotional distress
4. Negligent supervision and training

PRAYER FOR RELIEF:
WHEREFORE, Plaintiff respectfully requests that this Court:
1. Award compensatory damages in an amount to be determined at trial
2. Award punitive damages as permitted by law
3. Grant injunctive relief to prevent future violations
4. Award attorney's fees and costs
5. Grant such other and further relief as the Court deems just and proper

Date: ${new Date().toLocaleDateString('en-US')}

[Signature Line]
Plaintiff

---
NOTICE: This document is automatically generated and should be reviewed by a qualified attorney before filing.
Submit to: ${venue}
`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware setup
  await setupAuth(app);

  // ============================================
  // AUTH ROUTES
  // ============================================
  
  // Works for both authenticated and unauthenticated users
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      // If not authenticated, return null instead of error
      if (!req.isAuthenticated() || !req.user) {
        return res.json(null);
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ============================================
  // STRIPE PAYMENT ROUTES (Pay-per-use)
  // ============================================

  // Create Stripe Checkout Session for complaint filing
  app.post('/api/create-complaint-payment', isAuthenticated, async (req: any, res) => {
    try {
      const stripe = getStripeClient();
      const userId = req.user.claims.sub;
      const { complaintId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const complaint = await storage.getComplaint(complaintId);
      if (!complaint || complaint.userId !== userId) {
        return res.status(404).json({ message: "Complaint not found" });
      }

      // Create or get Stripe customer
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          name: user.firstName && user.lastName 
            ? `${user.firstName} ${user.lastName}` 
            : undefined,
          metadata: { userId: user.id }
        });
        customerId = customer.id;
        await storage.updateUserStripeCustomerId(user.id, customerId);
      }

      // Create Checkout Session for one-time payment
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'payment',
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              unit_amount: PRICING_CENTS,
              product_data: {
                name: 'Badge Check Complaint Filing',
                description: `Complaint against ${complaint.officerName}`,
              },
            },
            quantity: 1,
          },
        ],
        success_url: `${req.protocol}://${req.hostname}/complaint/${complaintId}?payment=success`,
        cancel_url: `${req.protocol}://${req.hostname}/complaint-form`,
        metadata: {
          userId: user.id,
          complaintId: complaintId,
          type: 'complaint',
        },
      });

      res.json({
        sessionId: session.id,
        url: session.url,
      });
    } catch (error: any) {
      console.error("Error creating payment session:", error);
      res.status(500).json({ message: "Error creating payment: " + error.message });
    }
  });

  // Create Stripe Checkout Session for lawsuit filing
  app.post('/api/create-lawsuit-payment', isAuthenticated, async (req: any, res) => {
    try {
      const stripe = getStripeClient();
      const userId = req.user.claims.sub;
      const { lawsuitId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const lawsuit = await storage.getLawsuitFiling(lawsuitId);
      if (!lawsuit || lawsuit.userId !== userId) {
        return res.status(404).json({ message: "Lawsuit not found" });
      }

      // Create or get Stripe customer
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          name: user.firstName && user.lastName 
            ? `${user.firstName} ${user.lastName}` 
            : undefined,
          metadata: { userId: user.id }
        });
        customerId = customer.id;
        await storage.updateUserStripeCustomerId(user.id, customerId);
      }

      // Create Checkout Session for one-time payment
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'payment',
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              unit_amount: PRICING_CENTS,
              product_data: {
                name: 'Badge Check Lawsuit Filing',
                description: `Civil rights lawsuit against ${lawsuit.officerName}`,
              },
            },
            quantity: 1,
          },
        ],
        success_url: `${req.protocol}://${req.hostname}/lawsuit/${lawsuitId}?payment=success`,
        cancel_url: `${req.protocol}://${req.hostname}/lawsuit-form`,
        metadata: {
          userId: user.id,
          lawsuitId: lawsuitId,
          type: 'lawsuit',
        },
      });

      res.json({
        sessionId: session.id,
        url: session.url,
      });
    } catch (error: any) {
      console.error("Error creating payment session:", error);
      res.status(500).json({ message: "Error creating payment: " + error.message });
    }
  });

  // Stripe webhook handler
  app.post('/api/webhooks/stripe', async (req, res) => {
    try {
      const stripe = getStripeClient();
      const sig = req.headers['stripe-signature'];
      
      if (!sig) {
        return res.status(400).send('Missing stripe signature');
      }

      // In production, verify webhook signature
      // For now, process the event directly
      const event = req.body;

      // Handle the event
      switch (event.type) {
        case 'checkout.session.completed': {
          const session = event.data.object;
          const { userId, complaintId, lawsuitId, type } = session.metadata;
          
          if (session.payment_status === 'paid') {
            const paymentIntentId = session.payment_intent as string;
            const amountPaid = session.amount_total || PRICING_CENTS;

            if (type === 'complaint' && complaintId) {
              // Update complaint with payment info
              await storage.updateComplaintPayment(
                complaintId,
                paymentIntentId,
                'completed',
                amountPaid
              );
              
              // Determine submission venue and update status
              const complaint = await storage.getComplaint(complaintId);
              if (complaint) {
                const submissionVenue = determineSubmissionVenue(
                  complaint.state, 
                  complaint.city, 
                  complaint.county, 
                  complaint.complaintType
                );
                await storage.updateComplaintStatus(complaintId, 'paid');
                console.log(`Complaint ${complaintId} should be submitted to: ${submissionVenue}`);
              }
            } else if (type === 'lawsuit' && lawsuitId) {
              // Update lawsuit with payment info
              await storage.updateLawsuitPayment(
                lawsuitId,
                paymentIntentId,
                'completed',
                amountPaid
              );
              
              // Generate lawsuit document with state-specific statutes
              const lawsuit = await storage.getLawsuitFiling(lawsuitId);
              if (lawsuit) {
                const document = generateLawsuitDocument(
                  lawsuit.state,
                  lawsuit.lawsuitType,
                  lawsuit.officerName,
                  lawsuit.officerBadge,
                  lawsuit.officerDepartment,
                  lawsuit.incidentDescription,
                  lawsuit.incidentDate,
                  lawsuit.city,
                  lawsuit.county
                );
                await storage.updateLawsuitStatus(lawsuitId, 'paid');
                console.log(`Lawsuit ${lawsuitId} document generated and ready for filing`);
              }
            }
          }
          break;
        }

        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("Webhook error:", error);
      res.status(400).send(`Webhook Error: ${error.message}`);
    }
  });

  // ============================================
  // BADGE LOOKUP ROUTES
  // ============================================

  // Analyze badge image with enhanced extraction
  app.post('/api/badge-lookups/analyze', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { imageData } = req.body;

      if (!imageData) {
        return res.status(400).json({ message: "No image data provided" });
      }

      // Check if OpenAI is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          message: "Badge analysis service is currently unavailable. The OpenAI API key has not been configured. Please contact support.",
          code: "SERVICE_UNAVAILABLE"
        });
      }

      // Analyze image with enhanced OpenAI Vision
      const analysis = await analyzeBadgeImage(imageData);

      // Lookup officer information if we have badge/department
      const officerInfo = analysis.badgeNumber || analysis.department 
        ? lookupOfficerInfo(
            analysis.badgeNumber || '', 
            analysis.department || '',
            analysis.officerName || undefined
          )
        : null;

      // Save lookup to database with enhanced fields
      const lookup = await storage.createBadgeLookup({
        userId,
        imageUrl: imageData.substring(0, 500), // Store truncated for space
        badgeNumber: analysis.badgeNumber || officerInfo?.badgeNumber || null,
        department: analysis.department || officerInfo?.department || null,
        officerName: analysis.officerName || officerInfo?.name || null,
        officerRank: analysis.officerRank || officerInfo?.rank || null,
        officerYears: officerInfo?.years || null,
        departmentLocation: officerInfo?.location || null,
        jurisdiction: analysis.jurisdiction || officerInfo?.jurisdiction || null,
        analysisConfidence: analysis.confidence,
        rawAiResponse: JSON.stringify({
          ...analysis,
          extractionSummary: {
            extracted: analysis.extractedFields,
            missing: analysis.missingFields,
            imageQuality: analysis.imageQuality,
            qualityIssues: analysis.qualityIssues,
          }
        }),
      });

      // Return enhanced analysis with extraction details
      res.json({
        ...lookup,
        enhancedAnalysis: {
          extractedFields: analysis.extractedFields,
          missingFields: analysis.missingFields,
          imageQuality: analysis.imageQuality,
          qualityIssues: analysis.qualityIssues,
          confidence: analysis.confidence,
          city: analysis.city,
          state: analysis.state,
          county: analysis.county,
          badgeType: analysis.badgeType,
          additionalInfo: analysis.additionalInfo,
        }
      });
    } catch (error: any) {
      console.error("Error analyzing badge:", error);
      
      // Provide user-friendly error messages
      if (error.message && error.message.includes('OPENAI_API_KEY')) {
        return res.status(503).json({ 
          message: "Badge analysis service is currently unavailable. Please try again later or contact support.",
          code: "SERVICE_UNAVAILABLE"
        });
      }
      
      res.status(500).json({ message: "Failed to analyze badge. Please try again." });
    }
  });

  // Manual officer search by name
  app.post('/api/officer-search/manual', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { name, badgeNumber, department } = req.body;

      if (!name) {
        return res.status(400).json({ message: "Officer name is required" });
      }

      // Lookup officer information using provided details
      const officerInfo = lookupOfficerInfo(
        badgeNumber || '', 
        department || '',
        name
      );

      // Save lookup to database
      const lookup = await storage.createBadgeLookup({
        userId,
        imageUrl: null, // No image for manual search
        badgeNumber: badgeNumber || officerInfo.badgeNumber,
        department: department || officerInfo.department,
        officerName: officerInfo.name,
        officerRank: officerInfo.rank,
        officerYears: officerInfo.years,
        departmentLocation: officerInfo.location,
        jurisdiction: officerInfo.jurisdiction,
        analysisConfidence: 'manual_search',
        rawAiResponse: `Manual search for officer: ${name}`,
      });

      res.json(lookup);
    } catch (error: any) {
      console.error("Error searching officer:", error);
      res.status(500).json({ message: "Failed to search officer: " + error.message });
    }
  });

  // Get all badge lookups for user
  app.get('/api/badge-lookups', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const lookups = await storage.getUserBadgeLookups(userId);
      res.json(lookups);
    } catch (error: any) {
      console.error("Error fetching lookups:", error);
      res.status(500).json({ message: "Failed to fetch lookups" });
    }
  });

  // Get specific badge lookup
  app.get('/api/badge-lookups/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const lookup = await storage.getBadgeLookup(id);
      
      if (!lookup) {
        return res.status(404).json({ message: "Lookup not found" });
      }
      
      // Verify ownership
      if (lookup.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(lookup);
    } catch (error: any) {
      console.error("Error fetching lookup:", error);
      res.status(500).json({ message: "Failed to fetch lookup" });
    }
  });

  // ============================================
  // COMPLAINT ROUTES
  // ============================================

  // Create complaint (then redirect to payment)
  app.post('/api/complaints', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Validate request body
      const validatedData = insertComplaintSchema.parse(req.body);
      
      const complaint = await storage.createComplaint({
        ...validatedData,
        userId,
        incidentDate: new Date(validatedData.incidentDate),
      });

      res.json(complaint);
    } catch (error: any) {
      console.error("Error creating complaint:", error);
      res.status(400).json({ message: "Failed to create complaint: " + error.message });
    }
  });

  // Get all complaints for user
  app.get('/api/complaints', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const complaints = await storage.getUserComplaints(userId);
      res.json(complaints);
    } catch (error: any) {
      console.error("Error fetching complaints:", error);
      res.status(500).json({ message: "Failed to fetch complaints" });
    }
  });

  // Get specific complaint
  app.get('/api/complaints/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const complaint = await storage.getComplaint(id);
      
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      
      // Verify ownership
      if (complaint.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(complaint);
    } catch (error: any) {
      console.error("Error fetching complaint:", error);
      res.status(500).json({ message: "Failed to fetch complaint" });
    }
  });

  // ============================================
  // LAWSUIT ROUTES
  // ============================================

  // Create lawsuit filing
  app.post('/api/lawsuits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Validate request body
      const validatedData = insertLawsuitFilingSchema.parse(req.body);
      
      const lawsuit = await storage.createLawsuitFiling({
        ...validatedData,
        userId,
        incidentDate: new Date(validatedData.incidentDate),
      });

      res.json(lawsuit);
    } catch (error: any) {
      console.error("Error creating lawsuit:", error);
      res.status(400).json({ message: "Failed to create lawsuit: " + error.message });
    }
  });

  // Get all lawsuits for user
  app.get('/api/lawsuits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const lawsuits = await storage.getUserLawsuitFilings(userId);
      res.json(lawsuits);
    } catch (error: any) {
      console.error("Error fetching lawsuits:", error);
      res.status(500).json({ message: "Failed to fetch lawsuits" });
    }
  });

  // Get specific lawsuit
  app.get('/api/lawsuits/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const lawsuit = await storage.getLawsuitFiling(id);
      
      if (!lawsuit) {
        return res.status(404).json({ message: "Lawsuit not found" });
      }
      
      // Verify ownership
      if (lawsuit.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(lawsuit);
    } catch (error: any) {
      console.error("Error fetching lawsuit:", error);
      res.status(500).json({ message: "Failed to fetch lawsuit" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
