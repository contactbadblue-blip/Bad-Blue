// Database Storage - from javascript_database and javascript_log_in_with_replit blueprints
import {
  users,
  badgeLookups,
  complaints,
  lawsuitFilings,
  type User,
  type UpsertUser,
  type BadgeLookup,
  type InsertBadgeLookup,
  type Complaint,
  type InsertComplaint,
  type LawsuitFiling,
  type InsertLawsuitFiling,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User>;
  
  // Badge lookup operations
  createBadgeLookup(lookup: InsertBadgeLookup): Promise<BadgeLookup>;
  getBadgeLookup(id: string): Promise<BadgeLookup | undefined>;
  getUserBadgeLookups(userId: string): Promise<BadgeLookup[]>;
  
  // Complaint operations
  createComplaint(complaint: InsertComplaint): Promise<Complaint>;
  getComplaint(id: string): Promise<Complaint | undefined>;
  getUserComplaints(userId: string): Promise<Complaint[]>;
  updateComplaintStatus(id: string, status: string): Promise<Complaint>;
  updateComplaintPayment(id: string, paymentId: string, paymentStatus: string, amountPaid: number): Promise<Complaint>;
  
  // Lawsuit filing operations
  createLawsuitFiling(filing: InsertLawsuitFiling): Promise<LawsuitFiling>;
  getLawsuitFiling(id: string): Promise<LawsuitFiling | undefined>;
  getUserLawsuitFilings(userId: string): Promise<LawsuitFiling[]>;
  updateLawsuitDocument(id: string, document: string, statutes: string[]): Promise<LawsuitFiling>;
  updateLawsuitPayment(id: string, paymentId: string, paymentStatus: string, amountPaid: number): Promise<LawsuitFiling>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeCustomerId(
    userId: string,
    stripeCustomerId: string
  ): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Badge lookup operations
  async createBadgeLookup(lookupData: InsertBadgeLookup): Promise<BadgeLookup> {
    const [lookup] = await db
      .insert(badgeLookups)
      .values(lookupData)
      .returning();
    return lookup;
  }

  async getBadgeLookup(id: string): Promise<BadgeLookup | undefined> {
    const [lookup] = await db
      .select()
      .from(badgeLookups)
      .where(eq(badgeLookups.id, id));
    return lookup;
  }

  async getUserBadgeLookups(userId: string): Promise<BadgeLookup[]> {
    return await db
      .select()
      .from(badgeLookups)
      .where(eq(badgeLookups.userId, userId))
      .orderBy(desc(badgeLookups.createdAt));
  }

  // Complaint operations
  async createComplaint(complaintData: InsertComplaint): Promise<Complaint> {
    const [complaint] = await db
      .insert(complaints)
      .values(complaintData as any)
      .returning();
    return complaint;
  }

  async getComplaint(id: string): Promise<Complaint | undefined> {
    const [complaint] = await db
      .select()
      .from(complaints)
      .where(eq(complaints.id, id));
    return complaint;
  }

  async getUserComplaints(userId: string): Promise<Complaint[]> {
    return await db
      .select()
      .from(complaints)
      .where(eq(complaints.userId, userId))
      .orderBy(desc(complaints.createdAt));
  }

  async updateComplaintStatus(id: string, status: string): Promise<Complaint> {
    const [complaint] = await db
      .update(complaints)
      .set({
        status,
        statusUpdatedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(complaints.id, id))
      .returning();
    return complaint;
  }

  async updateComplaintPayment(id: string, paymentId: string, paymentStatus: string, amountPaid: number): Promise<Complaint> {
    const [complaint] = await db
      .update(complaints)
      .set({
        paymentId,
        paymentStatus,
        amountPaid,
        updatedAt: new Date(),
      })
      .where(eq(complaints.id, id))
      .returning();
    return complaint;
  }

  // Lawsuit filing operations
  async createLawsuitFiling(filingData: InsertLawsuitFiling): Promise<LawsuitFiling> {
    const [filing] = await db
      .insert(lawsuitFilings)
      .values(filingData as any)
      .returning();
    return filing;
  }

  async getLawsuitFiling(id: string): Promise<LawsuitFiling | undefined> {
    const [filing] = await db
      .select()
      .from(lawsuitFilings)
      .where(eq(lawsuitFilings.id, id));
    return filing;
  }

  async getUserLawsuitFilings(userId: string): Promise<LawsuitFiling[]> {
    return await db
      .select()
      .from(lawsuitFilings)
      .where(eq(lawsuitFilings.userId, userId))
      .orderBy(desc(lawsuitFilings.createdAt));
  }

  async updateLawsuitDocument(id: string, document: string, statutes: string[]): Promise<LawsuitFiling> {
    const [filing] = await db
      .update(lawsuitFilings)
      .set({
        generatedDocument: document,
        stateStatutes: statutes,
        updatedAt: new Date(),
      })
      .where(eq(lawsuitFilings.id, id))
      .returning();
    return filing;
  }

  async updateLawsuitPayment(id: string, paymentId: string, paymentStatus: string, amountPaid: number): Promise<LawsuitFiling> {
    const [filing] = await db
      .update(lawsuitFilings)
      .set({
        paymentId,
        paymentStatus,
        amountPaid,
        updatedAt: new Date(),
      })
      .where(eq(lawsuitFilings.id, id))
      .returning();
    return filing;
  }
}

export const storage = new DatabaseStorage();
