// Badge Check - Database Schema
// Following javascript_log_in_with_replit and javascript_stripe blueprints

import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================
// SESSIONS TABLE (Required for Replit Auth)
// ============================================
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// ============================================
// USERS TABLE (Replit Auth + Stripe)
// ============================================
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  
  // Stripe customer tracking (for pay-per-use)
  stripeCustomerId: varchar("stripe_customer_id"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// ============================================
// BADGE LOOKUPS TABLE
// ============================================
export const badgeLookups = pgTable("badge_lookups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  
  // Image data
  imageUrl: text("image_url"), // Stored image path or base64
  
  // AI extracted data
  badgeNumber: varchar("badge_number"),
  department: text("department"),
  
  // Officer information (from public records)
  officerName: text("officer_name"),
  officerRank: text("officer_rank"),
  officerYears: integer("officer_years"),
  departmentLocation: text("department_location"),
  jurisdiction: text("jurisdiction"),
  
  // AI analysis metadata
  analysisConfidence: text("analysis_confidence"),
  rawAiResponse: text("raw_ai_response"),
  
  createdAt: timestamp("created_at").defaultNow(),
});

export const badgeLookupsRelations = relations(badgeLookups, ({ one }) => ({
  user: one(users, {
    fields: [badgeLookups.userId],
    references: [users.id],
  }),
}));

export const insertBadgeLookupSchema = createInsertSchema(badgeLookups).omit({
  id: true,
  createdAt: true,
});

export type InsertBadgeLookup = z.infer<typeof insertBadgeLookupSchema>;
export type BadgeLookup = typeof badgeLookups.$inferSelect;

// ============================================
// COMPLAINTS TABLE
// ============================================
export const complaints = pgTable("complaints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  badgeLookupId: varchar("badge_lookup_id").references(() => badgeLookups.id, { onDelete: 'set null' }),
  
  // Officer information
  officerName: text("officer_name").notNull(),
  officerBadge: varchar("officer_badge"),
  officerDepartment: text("officer_department").notNull(),
  
  // Jurisdiction
  state: varchar("state", { length: 2 }).notNull(), // US state code (e.g., "IA", "CA")
  city: text("city").notNull(),
  
  // Complaint type
  complaintType: varchar("complaint_type").notNull(), // 'assault', 'negligence', 'harassment', 'excessive-force', 'misconduct', 'discrimination', 'other'
  
  // Incident details
  incidentDate: timestamp("incident_date").notNull(),
  incidentTime: varchar("incident_time"),
  description: text("description").notNull(),
  
  // Evidence
  evidenceUrls: text("evidence_urls").array(),
  
  // Submission routing (auto-determined)
  submissionVenue: varchar("submission_venue"), // 'internal_affairs', 'police_chief', 'sheriff', 'city_attorney'
  submissionEmail: text("submission_email"),
  submissionAddress: text("submission_address"),
  
  // Status tracking
  status: varchar("status").notNull().default('pending'), // 'pending', 'paid', 'submitted', 'under_review', 'resolved', 'closed'
  statusUpdatedAt: timestamp("status_updated_at").defaultNow(),
  submittedAt: timestamp("submitted_at"),
  
  // Payment tracking
  paymentId: varchar("payment_id"), // Stripe payment intent ID
  paymentStatus: varchar("payment_status").default('pending'), // 'pending', 'completed', 'failed'
  amountPaid: integer("amount_paid"), // Amount in cents
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const complaintsRelations = relations(complaints, ({ one }) => ({
  user: one(users, {
    fields: [complaints.userId],
    references: [users.id],
  }),
  badgeLookup: one(badgeLookups, {
    fields: [complaints.badgeLookupId],
    references: [badgeLookups.id],
  }),
}));

export const insertComplaintSchema = createInsertSchema(complaints).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  statusUpdatedAt: true,
  submittedAt: true,
  submissionVenue: true,
  submissionEmail: true,
  submissionAddress: true,
  paymentId: true,
  paymentStatus: true,
  amountPaid: true,
}).extend({
  incidentDate: z.string().or(z.date()), // Accept ISO string or Date
});

export type InsertComplaint = z.infer<typeof insertComplaintSchema>;
export type Complaint = typeof complaints.$inferSelect;

// ============================================
// PRICING (Pay-per-use model)
// ============================================
export const PRICING = 29.99; // Price per submission in USD

export const PRICING_CENTS = 2999; // Price in cents for Stripe

export const COMPLAINT_TYPES = [
  'assault',
  'excessive-force',
  'harassment',
  'negligence',
  'misconduct',
  'discrimination',
  'other'
] as const;

// ============================================
// LAWSUIT FILINGS TABLE
// ============================================
export const lawsuitFilings = pgTable("lawsuit_filings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  complaintId: varchar("complaint_id").references(() => complaints.id, { onDelete: 'set null' }),
  
  // Officer information
  officerName: text("officer_name").notNull(),
  officerBadge: varchar("officer_badge"),
  officerDepartment: text("officer_department").notNull(),
  
  // Jurisdiction
  state: varchar("state", { length: 2 }).notNull(), // US state code
  city: text("city").notNull(),
  county: text("county"),
  
  // Lawsuit type and details
  lawsuitType: varchar("lawsuit_type").notNull(), // 'assault', 'negligence', 'harassment', 'excessive-force', 'misconduct', 'discrimination', 'other'
  incidentDate: timestamp("incident_date").notNull(),
  description: text("description").notNull(),
  
  // Damages
  damagesRequested: integer("damages_requested"), // Amount in cents
  injuryDetails: text("injury_details"),
  medicalCosts: integer("medical_costs"), // Amount in cents
  
  // Evidence
  evidenceUrls: text("evidence_urls").array(),
  witnessNames: text("witness_names").array(),
  
  // Auto-generated legal document
  generatedDocument: text("generated_document"), // Full lawsuit template with state statutes
  stateStatutes: text("state_statutes").array(), // Relevant state codes/statutes
  
  // Filing information
  filingCourt: text("filing_court"), // Auto-determined court venue
  filingAddress: text("filing_address"),
  filingInstructions: text("filing_instructions"),
  
  // Status tracking
  status: varchar("status").notNull().default('pending'), // 'pending', 'paid', 'document_ready', 'filed', 'in_progress', 'settled', 'dismissed'
  statusUpdatedAt: timestamp("status_updated_at").defaultNow(),
  
  // Payment tracking
  paymentId: varchar("payment_id"), // Stripe payment intent ID
  paymentStatus: varchar("payment_status").default('pending'),
  amountPaid: integer("amount_paid"), // Amount in cents
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const lawsuitFilingsRelations = relations(lawsuitFilings, ({ one }) => ({
  user: one(users, {
    fields: [lawsuitFilings.userId],
    references: [users.id],
  }),
  complaint: one(complaints, {
    fields: [lawsuitFilings.complaintId],
    references: [complaints.id],
  }),
}));

export const insertLawsuitFilingSchema = createInsertSchema(lawsuitFilings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  statusUpdatedAt: true,
  generatedDocument: true,
  stateStatutes: true,
  filingCourt: true,
  filingAddress: true,
  filingInstructions: true,
  paymentId: true,
  paymentStatus: true,
  amountPaid: true,
}).extend({
  incidentDate: z.string().or(z.date()),
});

export type InsertLawsuitFiling = z.infer<typeof insertLawsuitFilingSchema>;
export type LawsuitFiling = typeof lawsuitFilings.$inferSelect;
