import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Search, FileText, TrendingUp, Upload, Database, Bell, Check } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import heroImage from "@assets/generated_images/Civic_accountability_hero_image_a13a823c.png";

export default function Landing() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Image with Dark Wash */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
        </div>

        {/* Theme Toggle - Fixed top right */}
        <div className="absolute top-6 right-6 z-20">
          <ThemeToggle />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-white text-5xl md:text-6xl font-bold leading-tight mb-6">
            Police Accountability Made Accessible
          </h1>
          <p className="text-white/90 text-xl md:text-2xl mb-8 leading-relaxed">
            Instant access to officer information through public records. Upload badge photos, verify credentials, and promote transparency.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg"
              className="text-lg px-8 py-6 bg-primary/90 hover:bg-primary backdrop-blur-sm border-2 border-primary-border"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-get-started"
            >
              Get Started Free
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 bg-white/10 hover:bg-white/20 backdrop-blur-md border-2 text-white border-white/30"
              onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
          
          {/* Trust Indicator */}
          <div className="mt-12">
            <Badge className="bg-white/15 backdrop-blur-md text-white border-white/20 px-4 py-2 text-sm">
              <Shield className="w-4 h-4 mr-2" />
              Powered by Public Records
            </Badge>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
            <div className="w-1.5 h-3 bg-white/70 rounded-full" />
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Transparency Through Technology</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Access the public information you have a right to know, with tools designed for accountability and transparency.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-8 hover-elevate">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Instant Verification</h3>
              <p className="text-muted-foreground leading-relaxed">
                Upload a badge photo and get immediate access to officer information from public records databases. Know who you're interacting with in seconds.
              </p>
            </Card>

            <Card className="p-8 hover-elevate">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">File Complaints</h3>
              <p className="text-muted-foreground leading-relaxed">
                Document incidents and file official complaints with detailed information. Track the progress of your submissions with Premium tier.
              </p>
            </Card>

            <Card className="p-8 hover-elevate">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Data-Driven Insights</h3>
              <p className="text-muted-foreground leading-relaxed">
                Access analytics and trends to understand patterns of accountability. Premium users get advanced reporting and bulk analysis tools.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 px-4 bg-card">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground">
              Four simple steps to access officer information and promote accountability
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { num: "01", icon: Upload, title: "Upload Badge Photo", desc: "Take a photo of an officer's badge or upload an existing image from your device." },
              { num: "02", icon: Search, title: "AI Analysis", desc: "Our AI extracts the badge number and department information from your photo instantly." },
              { num: "03", icon: Database, title: "Access Records", desc: "Retrieve officer name, rank, department location, and other public information." },
              { num: "04", icon: FileText, title: "File or Track", desc: "File complaints or track existing ones with detailed status updates (Premium)." },
            ].map((step) => (
              <div key={step.num} className="text-center">
                <div className="font-mono text-5xl font-bold text-primary/20 mb-4">{step.num}</div>
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Choose Your Plan</h2>
            <p className="text-xl text-muted-foreground">
              Start with Basic for essential features, upgrade to Premium for advanced tracking
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Basic Tier */}
            <Card className="p-8 border-2">
              <div className="mb-6">
                <h3 className="text-2xl font-semibold mb-2">Basic</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold">$10.99</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {[
                  "AI-powered badge analysis",
                  "Unlimited badge searches",
                  "Officer information lookup",
                  "File complaints",
                  "Search history",
                ].map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                className="w-full" 
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-basic-subscribe"
              >
                Get Started
              </Button>
            </Card>

            {/* Premium Tier */}
            <Card className="p-8 border-2 border-primary relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <Badge className="bg-primary text-primary-foreground">Recommended</Badge>
              </div>
              
              <div className="mb-6">
                <h3 className="text-2xl font-semibold mb-2">Premium</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold">$19.99</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {[
                  "Everything in Basic",
                  "Complaint status tracking",
                  "Advanced analytics dashboard",
                  "Bulk badge uploads",
                  "Export data (CSV/PDF)",
                  "Priority support",
                ].map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className={feature === "Everything in Basic" ? "font-medium" : ""}>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                className="w-full" 
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-premium-subscribe"
              >
                Get Premium
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Trust & Transparency */}
      <section className="py-16 px-4 bg-card">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Our Commitment to Accuracy</h2>
          <div className="space-y-4 text-muted-foreground leading-relaxed">
            <p>
              Badge Check aggregates information from publicly available records and databases maintained by law enforcement agencies. All information provided is sourced from official public records that citizens have the legal right to access.
            </p>
            <p>
              We are committed to accuracy and transparency. If you believe any information is incorrect or needs updating, please contact us at{" "}
              <a href="mailto:support@badgecheck.com" className="text-primary hover:underline">
                support@badgecheck.com
              </a>
            </p>
            <p className="text-sm pt-4">
              By using Badge Check, you agree to use the information responsibly and in accordance with applicable laws. This service is provided for transparency and accountability purposes.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Badge Check
              </h3>
              <p className="text-sm text-muted-foreground">
                Making public records accessible for everyone.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#how-it-works" className="hover:text-foreground">How It Works</a></li>
                <li><a href="#" className="hover:text-foreground">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-foreground">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="mailto:support@badgecheck.com" className="hover:text-foreground">Support</a></li>
                <li><a href="mailto:corrections@badgecheck.com" className="hover:text-foreground">Report Issue</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2025 Badge Check. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
