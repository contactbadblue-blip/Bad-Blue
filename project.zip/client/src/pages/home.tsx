import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Shield, Upload, FileText, Scale, ChevronRight, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import heroImage from "@assets/images_1761389232912.jpeg";
import { COMPLAINT_TYPES } from "@shared/schema";

const US_STATES = [
  { code: 'AL', name: 'Alabama' },
  { code: 'AK', name: 'Alaska' },
  { code: 'AZ', name: 'Arizona' },
  { code: 'AR', name: 'Arkansas' },
  { code: 'CA', name: 'California' },
  { code: 'CO', name: 'Colorado' },
  { code: 'CT', name: 'Connecticut' },
  { code: 'DE', name: 'Delaware' },
  { code: 'FL', name: 'Florida' },
  { code: 'GA', name: 'Georgia' },
  { code: 'HI', name: 'Hawaii' },
  { code: 'ID', name: 'Idaho' },
  { code: 'IL', name: 'Illinois' },
  { code: 'IN', name: 'Indiana' },
  { code: 'IA', name: 'Iowa' },
  { code: 'KS', name: 'Kansas' },
  { code: 'KY', name: 'Kentucky' },
  { code: 'LA', name: 'Louisiana' },
  { code: 'ME', name: 'Maine' },
  { code: 'MD', name: 'Maryland' },
  { code: 'MA', name: 'Massachusetts' },
  { code: 'MI', name: 'Michigan' },
  { code: 'MN', name: 'Minnesota' },
  { code: 'MS', name: 'Mississippi' },
  { code: 'MO', name: 'Missouri' },
  { code: 'MT', name: 'Montana' },
  { code: 'NE', name: 'Nebraska' },
  { code: 'NV', name: 'Nevada' },
  { code: 'NH', name: 'New Hampshire' },
  { code: 'NJ', name: 'New Jersey' },
  { code: 'NM', name: 'New Mexico' },
  { code: 'NY', name: 'New York' },
  { code: 'NC', name: 'North Carolina' },
  { code: 'ND', name: 'North Dakota' },
  { code: 'OH', name: 'Ohio' },
  { code: 'OK', name: 'Oklahoma' },
  { code: 'OR', name: 'Oregon' },
  { code: 'PA', name: 'Pennsylvania' },
  { code: 'RI', name: 'Rhode Island' },
  { code: 'SC', name: 'South Carolina' },
  { code: 'SD', name: 'South Dakota' },
  { code: 'TN', name: 'Tennessee' },
  { code: 'TX', name: 'Texas' },
  { code: 'UT', name: 'Utah' },
  { code: 'VT', name: 'Vermont' },
  { code: 'VA', name: 'Virginia' },
  { code: 'WA', name: 'Washington' },
  { code: 'WV', name: 'West Virginia' },
  { code: 'WI', name: 'Wisconsin' },
  { code: 'WY', name: 'Wyoming' },
];

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState<'initial' | 'officer-entry' | 'analyzing' | 'action-selection'>('initial');
  const [officerName, setOfficerName] = useState("");
  const [badgePhoto, setBadgePhoto] = useState<string | null>(null);
  const [badgeAnalysis, setBadgeAnalysis] = useState<any>(null);
  const [selectedAction, setSelectedAction] = useState<'complaint' | 'lawsuit' | null>(null);
  const [selectedState, setSelectedState] = useState("");
  const [selectedType, setSelectedType] = useState("");

  // Badge analysis mutation
  const analyzeMutation = useMutation({
    mutationFn: async (imageData: string) => {
      const response = await apiRequest("POST", "/api/badge-lookups/analyze", {
        imageData,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      setBadgeAnalysis(data);
      setStep('action-selection');
      toast({
        title: "Badge Analyzed Successfully",
        description: `Extracted ${data.enhancedAnalysis?.extractedFields?.length || 0} fields from badge photo`,
      });
    },
    onError: (error: Error) => {
      setStep('officer-entry');
      toast({
        title: "Analysis Failed",
        description: error.message || "Could not analyze badge. Please enter information manually.",
        variant: "destructive",
      });
    },
  });

  const handleBadgeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to use badge analysis",
        variant: "destructive",
      });
      window.location.href = "/api/login";
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const imageData = reader.result as string;
      setBadgePhoto(imageData);
      setStep('analyzing');
      // Analyze immediately
      analyzeMutation.mutate(imageData);
    };
    reader.readAsDataURL(file);
  };

  const handleNameSubmit = () => {
    if (!officerName.trim()) {
      toast({
        title: "Required",
        description: "Please enter the officer's name",
        variant: "destructive",
      });
      return;
    }
    setStep('action-selection');
  };

  const handleActionSelection = (action: 'complaint' | 'lawsuit') => {
    if (!user) {
      window.location.href = "/api/login";
      return;
    }
    
    setSelectedAction(action);
    
    // Store badge analysis in sessionStorage for form auto-fill
    if (badgeAnalysis) {
      sessionStorage.setItem('badgeAnalysis', JSON.stringify(badgeAnalysis));
    }
    if (officerName && !badgeAnalysis) {
      sessionStorage.setItem('manualOfficerName', officerName);
    }
    
    // Navigate to appropriate form
    if (action === 'complaint') {
      window.location.href = '/complaint-form';
    } else {
      window.location.href = '/lawsuit-form';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            <span className="font-semibold text-lg">Badge Check</span>
          </div>
          
          <div className="flex items-center gap-2">
            <ThemeToggle />
            {user ? (
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = "/api/logout"}
                data-testid="button-logout"
              >
                Sign Out
              </Button>
            ) : (
              <Button 
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-login"
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      {step === 'initial' && (
        <section className="relative bg-gradient-to-b from-primary/5 to-background">
          <div className="max-w-7xl mx-auto px-4 py-16">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left Column - Text */}
              <div className="space-y-6">
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
                  Hold Law Enforcement Accountable.{" "}
                  <span className="text-primary">With Convenience.</span>
                </h1>
                <p className="text-xl text-muted-foreground">
                  File formal complaints or civil rights lawsuits against police officers with AI-powered assistance. 
                  We handle the paperwork, routing, and submission — you focus on justice.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    size="lg" 
                    onClick={() => setStep('officer-entry')}
                    className="text-lg h-12"
                    data-testid="button-get-started"
                  >
                    Get Started
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="text-lg h-12"
                    data-testid="button-learn-more"
                  >
                    How It Works
                  </Button>
                </div>
                <div className="pt-4">
                  <p className="text-sm text-muted-foreground font-medium">
                    $29.99 per submission • Secure & Confidential • Expert Legal Templates
                  </p>
                </div>
              </div>

              {/* Right Column - Image */}
              <div className="relative">
                <img 
                  src={heroImage} 
                  alt="Diverse citizens united for justice and police accountability"
                  className="rounded-lg shadow-2xl w-full"
                  data-testid="img-hero"
                />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Officer Entry Step */}
      {step === 'officer-entry' && (
        <main className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Identify the Officer</h2>
            <p className="text-muted-foreground">Upload a badge photo or enter the officer's name manually</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Badge Upload Option */}
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  Upload Badge Photo
                </CardTitle>
                <CardDescription>
                  AI-powered badge analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <input
                      type="file"
                      id="badge-upload"
                      accept="image/*"
                      onChange={handleBadgeUpload}
                      className="hidden"
                      data-testid="input-badge-upload"
                    />
                    <label htmlFor="badge-upload" className="cursor-pointer">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Upload className="w-8 h-8 text-primary" />
                      </div>
                      <p className="font-medium mb-1">Click to upload badge photo</p>
                      <p className="text-sm text-muted-foreground">PNG, JPG up to 10MB</p>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Manual Name Entry Option */}
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Enter Name Manually
                </CardTitle>
                <CardDescription>
                  Type the officer's information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="officer-name">Officer Name</Label>
                    <Input
                      id="officer-name"
                      placeholder="Full name"
                      value={officerName}
                      onChange={(e) => setOfficerName(e.target.value)}
                      data-testid="input-officer-name"
                    />
                  </div>
                  <Button 
                    onClick={handleNameSubmit}
                    className="w-full"
                    data-testid="button-continue-name"
                  >
                    Continue
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      )}

      {/* Badge Analyzing Step */}
      {step === 'analyzing' && (
        <main className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center">
            <Card>
              <CardContent className="pt-12 pb-12">
                <div className="flex flex-col items-center gap-4">
                  <Loader2 className="w-16 h-16 text-primary animate-spin" />
                  <h2 className="text-2xl font-bold">Analyzing Badge Photo...</h2>
                  <p className="text-muted-foreground max-w-md">
                    Our AI is extracting officer information, badge number, department details, and jurisdiction data from your photo.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      )}

      {/* Action Selection Step */}
      {step === 'action-selection' && (
        <main className="max-w-4xl mx-auto px-4 py-12">
          <div className="mb-8">
            {badgeAnalysis && badgeAnalysis.enhancedAnalysis && (
              <Card className="mb-6 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                    Badge Analysis Complete
                  </CardTitle>
                  <CardDescription>
                    Extracted information will auto-fill your forms
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    {badgeAnalysis.enhancedAnalysis.extractedFields.length > 0 && (
                      <div className="space-y-2">
                        <p className="font-semibold text-green-600 dark:text-green-400 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" />
                          Successfully Extracted ({badgeAnalysis.enhancedAnalysis.extractedFields.length})
                        </p>
                        <ul className="space-y-1 text-muted-foreground">
                          {badgeAnalysis.enhancedAnalysis.extractedFields.map((field: string) => (
                            <li key={field} className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-green-600 dark:bg-green-400" />
                              {field.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {badgeAnalysis.enhancedAnalysis.missingFields.length > 0 && (
                      <div className="space-y-2">
                        <p className="font-semibold text-orange-600 dark:text-orange-400 flex items-center gap-2">
                          <XCircle className="w-4 h-4" />
                          Could Not Extract ({badgeAnalysis.enhancedAnalysis.missingFields.length})
                        </p>
                        <ul className="space-y-1 text-muted-foreground">
                          {badgeAnalysis.enhancedAnalysis.missingFields.map((field: string) => (
                            <li key={field} className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-orange-600 dark:bg-orange-400" />
                              {field.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                  {badgeAnalysis.enhancedAnalysis.qualityIssues.length > 0 && (
                    <div className="pt-2 border-t">
                      <p className="text-sm text-muted-foreground">
                        <span className="font-medium">Image Quality Issues:</span> {badgeAnalysis.enhancedAnalysis.qualityIssues.join(', ')}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
            
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-2">Choose Your Action</h2>
              <p className="text-muted-foreground">
                {badgeAnalysis ? 'Badge analyzed - fields will auto-fill' : (badgePhoto ? 'Badge uploaded successfully' : `Officer: ${officerName}`)}
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* File Complaint Option */}
            <Card className="hover-elevate cursor-pointer" onClick={() => handleActionSelection('complaint')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <FileText className="w-6 h-6" />
                  File a Complaint
                </CardTitle>
                <CardDescription className="text-base">
                  Submit a formal complaint to the appropriate department
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>Auto-routed to Internal Affairs, Police Chief, or Sheriff</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>Choose from assault, harassment, negligence, and more</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>Upload evidence (photos, videos, documents)</span>
                  </li>
                </ul>
                <Button className="w-full" size="lg" data-testid="button-file-complaint">
                  File Complaint - $29.99
                </Button>
              </CardContent>
            </Card>

            {/* File Lawsuit Option */}
            <Card className="hover-elevate cursor-pointer" onClick={() => handleActionSelection('lawsuit')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Scale className="w-6 h-6" />
                  File a Lawsuit
                </CardTitle>
                <CardDescription className="text-base">
                  Generate legal documents for civil rights litigation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>State-specific legal templates with proper statutes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>Auto-determined court venue and filing instructions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>Professional lawsuit document ready to file</span>
                  </li>
                </ul>
                <Button className="w-full" size="lg" data-testid="button-file-lawsuit">
                  File Lawsuit - $29.99
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button 
              variant="ghost" 
              onClick={() => {
                setStep('officer-entry');
                setBadgePhoto(null);
                setOfficerName('');
              }}
              data-testid="button-back"
            >
              ← Go Back
            </Button>
          </div>
        </main>
      )}
    </div>
  );
}
