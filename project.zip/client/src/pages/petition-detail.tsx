import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Users, AlertTriangle, ArrowLeft, CheckCircle, Calendar, Shield } from "lucide-react";

const signatureSchema = z.object({
  signerName: z.string().min(2, "Name must be at least 2 characters"),
  signerEmail: z.string().email("Valid email required").optional().or(z.literal("")),
  signerZipCode: z.string().min(5, "Valid zip code required").max(10),
});

type SignatureFormData = z.infer<typeof signatureSchema>;

export default function PetitionDetail() {
  const [match, params] = useRoute("/petitions/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [hasSigned, setHasSigned] = useState(false);

  const petitionId = params?.id;

  const { data: petition, isLoading } = useQuery({
    queryKey: ['/api/petitions', petitionId],
    enabled: !!petitionId,
  });

  const { data: user } = useQuery({
    queryKey: ['/api/auth/user'],
  });

  const form = useForm<SignatureFormData>({
    resolver: zodResolver(signatureSchema),
    defaultValues: {
      signerName: "",
      signerEmail: "",
      signerZipCode: "",
    },
  });

  const signPetitionMutation = useMutation({
    mutationFn: async (data: SignatureFormData) => {
      return await apiRequest(`/api/petitions/${petitionId}/sign`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/petitions', petitionId] });
      queryClient.invalidateQueries({ queryKey: ['/api/petitions'] });
      setHasSigned(true);
      toast({
        title: "Petition Signed",
        description: "Thank you for your support!",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to sign petition",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: SignatureFormData) => {
    await signPetitionMutation.mutateAsync(data);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="h-48 bg-muted animate-pulse rounded" />
          <div className="h-64 bg-muted animate-pulse rounded" />
        </div>
      </div>
    );
  }

  if (!petition) {
    return (
      <div className="container mx-auto p-6">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">Petition not found</p>
              <Button onClick={() => navigate("/petitions")} className="mt-4" data-testid="button-back">
                Back to Petitions
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/petitions")}
          data-testid="button-back-nav"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to All Petitions
        </Button>

        {/* Petition Header */}
        <Card className="border-orange-500/20 bg-orange-500/5">
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <CardTitle className="text-2xl mb-2 flex items-center gap-2">
                  <AlertTriangle className="h-6 w-6 text-orange-500" />
                  <span data-testid="title-petition">Petition for Officer Resignation</span>
                </CardTitle>
                <CardDescription className="text-base">
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="h-4 w-4" />
                    <span data-testid="text-officer-name">Officer {petition.officerName}</span>
                  </div>
                  <div data-testid="text-department">{petition.officerDepartment}</div>
                  {petition.officerBadge && <div>Badge #{petition.officerBadge}</div>}
                </CardDescription>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Badge variant="default" className="text-lg px-4 py-2" data-testid="badge-signature-count">
                  <Users className="h-5 w-5 mr-2" />
                  {petition.signatureCount}
                </Badge>
                <Badge variant="secondary" data-testid="badge-status">
                  {petition.status.toUpperCase()}
                </Badge>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Petition Details */}
        <Card>
          <CardHeader>
            <CardTitle>Petition Statement</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-foreground whitespace-pre-wrap" data-testid="text-reason">
              {petition.reason}
            </p>

            {petition.complaintIds && petition.complaintIds.length > 0 && (
              <div className="pt-4 border-t">
                <p className="text-sm text-muted-foreground">
                  This petition is based on <strong>{petition.complaintIds.length}</strong> filed {petition.complaintIds.length === 1 ? 'complaint' : 'complaints'} against this officer.
                </p>
              </div>
            )}

            <div className="pt-4 border-t flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              Created {new Date(petition.createdAt).toLocaleDateString()}
            </div>
          </CardContent>
        </Card>

        {/* Sign Petition */}
        {hasSigned ? (
          <Card className="border-green-500/20 bg-green-500/5">
            <CardContent className="py-8 text-center">
              <CheckCircle className="h-16 w-16 mx-auto text-green-500 mb-4" />
              <p className="text-lg font-semibold mb-2" data-testid="text-signed">Thank you for signing!</p>
              <p className="text-muted-foreground">
                Your signature has been recorded and will be included when this petition is sent to the department.
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Sign This Petition</CardTitle>
              <CardDescription>
                Add your voice to call for accountability and departmental review
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="signerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} data-testid="input-signer-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="signerEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email (Optional)</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john@example.com" {...field} data-testid="input-signer-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="signerZipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Zip Code</FormLabel>
                        <FormControl>
                          <Input placeholder="12345" {...field} data-testid="input-signer-zip" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    disabled={signPetitionMutation.isPending}
                    className="w-full"
                    data-testid="button-sign"
                  >
                    {signPetitionMutation.isPending ? "Signing..." : "Sign Petition"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}

        {/* Recent Signatures */}
        {petition.signatures && petition.signatures.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Signatures ({petition.signatures.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {petition.signatures.slice(0, 10).map((sig: any, index: number) => (
                  <div 
                    key={sig.id} 
                    className="flex items-center justify-between py-2 border-b last:border-0"
                    data-testid={`signature-${index}`}
                  >
                    <span className="font-medium">{sig.signerName || "Anonymous"}</span>
                    <span className="text-sm text-muted-foreground">
                      {new Date(sig.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
                {petition.signatures.length > 10 && (
                  <p className="text-sm text-muted-foreground text-center pt-2">
                    And {petition.signatures.length - 10} more...
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
