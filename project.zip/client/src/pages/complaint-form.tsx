import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Shield, FileText, DollarSign, CheckCircle2, XCircle, Sparkles } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { COMPLAINT_TYPES, PRICING } from "@shared/schema";

const US_STATES = [
  { code: 'AL', name: 'Alabama' }, { code: 'AK', name: 'Alaska' }, { code: 'AZ', name: 'Arizona' },
  { code: 'AR', name: 'Arkansas' }, { code: 'CA', name: 'California' }, { code: 'CO', name: 'Colorado' },
  { code: 'CT', name: 'Connecticut' }, { code: 'DE', name: 'Delaware' }, { code: 'FL', name: 'Florida' },
  { code: 'GA', name: 'Georgia' }, { code: 'HI', name: 'Hawaii' }, { code: 'ID', name: 'Idaho' },
  { code: 'IL', name: 'Illinois' }, { code: 'IN', name: 'Indiana' }, { code: 'IA', name: 'Iowa' },
  { code: 'KS', name: 'Kansas' }, { code: 'KY', name: 'Kentucky' }, { code: 'LA', name: 'Louisiana' },
  { code: 'ME', name: 'Maine' }, { code: 'MD', name: 'Maryland' }, { code: 'MA', name: 'Massachusetts' },
  { code: 'MI', name: 'Michigan' }, { code: 'MN', name: 'Minnesota' }, { code: 'MS', name: 'Mississippi' },
  { code: 'MO', name: 'Missouri' }, { code: 'MT', name: 'Montana' }, { code: 'NE', name: 'Nebraska' },
  { code: 'NV', name: 'Nevada' }, { code: 'NH', name: 'New Hampshire' }, { code: 'NJ', name: 'New Jersey' },
  { code: 'NM', name: 'New Mexico' }, { code: 'NY', name: 'New York' }, { code: 'NC', name: 'North Carolina' },
  { code: 'ND', name: 'North Dakota' }, { code: 'OH', name: 'Ohio' }, { code: 'OK', name: 'Oklahoma' },
  { code: 'OR', name: 'Oregon' }, { code: 'PA', name: 'Pennsylvania' }, { code: 'RI', name: 'Rhode Island' },
  { code: 'SC', name: 'South Carolina' }, { code: 'SD', name: 'South Dakota' }, { code: 'TN', name: 'Tennessee' },
  { code: 'TX', name: 'Texas' }, { code: 'UT', name: 'Utah' }, { code: 'VT', name: 'Vermont' },
  { code: 'VA', name: 'Virginia' }, { code: 'WA', name: 'Washington' }, { code: 'WV', name: 'West Virginia' },
  { code: 'WI', name: 'Wisconsin' }, { code: 'WY', name: 'Wyoming' },
];

export default function ComplaintForm() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [officerName, setOfficerName] = useState("");
  const [badgeNumber, setBadgeNumber] = useState("");
  const [department, setDepartment] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [complaintType, setComplaintType] = useState("");
  const [description, setDescription] = useState("");
  const [incidentDate, setIncidentDate] = useState("");
  const [badgeAnalysis, setBadgeAnalysis] = useState<any>(null);
  const [autoFilledFields, setAutoFilledFields] = useState<string[]>([]);

  // Auto-fill from badge analysis on component mount
  useEffect(() => {
    const analysisData = sessionStorage.getItem('badgeAnalysis');
    const manualName = sessionStorage.getItem('manualOfficerName');
    
    if (analysisData) {
      try {
        const analysis = JSON.parse(analysisData);
        setBadgeAnalysis(analysis);
        const filled: string[] = [];
        
        // Auto-fill fields from badge analysis
        if (analysis.officerName) {
          setOfficerName(analysis.officerName);
          filled.push('Officer Name');
        }
        if (analysis.badgeNumber) {
          setBadgeNumber(analysis.badgeNumber);
          filled.push('Badge Number');
        }
        if (analysis.department) {
          setDepartment(analysis.department);
          filled.push('Department');
        }
        if (analysis.enhancedAnalysis?.state) {
          setState(analysis.enhancedAnalysis.state);
          filled.push('State');
        }
        if (analysis.enhancedAnalysis?.city) {
          setCity(analysis.enhancedAnalysis.city);
          filled.push('City');
        }
        
        setAutoFilledFields(filled);
        
        if (filled.length > 0) {
          toast({
            title: "Form Auto-Filled",
            description: `${filled.length} fields populated from badge analysis`,
          });
        }
        
        // Clear the sessionStorage
        sessionStorage.removeItem('badgeAnalysis');
      } catch (error) {
        console.error("Failed to parse badge analysis:", error);
      }
    } else if (manualName) {
      setOfficerName(manualName);
      sessionStorage.removeItem('manualOfficerName');
    }
  }, []);
  
  const submitMutation = useMutation({
    mutationFn: async (data: any) => {
      // Step 1: Create the complaint
      const complaintResponse = await apiRequest("POST", "/api/complaints", data);
      const complaint = await complaintResponse.json();
      
      // Step 2: Create payment session
      const paymentResponse = await apiRequest("POST", "/api/create-complaint-payment", {
        complaintId: complaint.id,
      });
      const paymentData = await paymentResponse.json();
      
      return { complaint, paymentUrl: paymentData.url };
    },
    onSuccess: (data) => {
      toast({
        title: "Complaint Created",
        description: "Redirecting to payment...",
      });
      // Redirect to Stripe Checkout
      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit complaint",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!officerName || !state || !city || !complaintType || !description || !incidentDate) {
      toast({
        title: "Required Fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    submitMutation.mutate({
      officerName,
      badgeNumber: badgeNumber || null,
      department: department || null,
      state,
      city,
      complaintType,
      description,
      incidentDate,
    });
  };

  if (!user) {
    window.location.href = "/api/login";
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            <span className="font-semibold text-lg">Badge Check</span>
          </div>
          
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              onClick={() => window.location.href = "/api/logout"}
              data-testid="button-logout"
            >
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">File a Complaint</h1>
          <p className="text-muted-foreground">
            Submit a formal complaint against a law enforcement officer. We'll auto-route it to the appropriate department.
          </p>
        </div>

        {/* Badge Analysis Summary */}
        {badgeAnalysis && badgeAnalysis.enhancedAnalysis && (
          <Card className="mb-6 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Badge Analysis Results
              </CardTitle>
              <CardDescription>
                Fields marked with ✓ were auto-filled from your badge photo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                {badgeAnalysis.enhancedAnalysis.extractedFields.length > 0 && (
                  <div className="space-y-2">
                    <p className="font-semibold text-green-600 dark:text-green-400 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Auto-Filled ({autoFilledFields.length})
                    </p>
                    <ul className="space-y-1 text-muted-foreground">
                      {autoFilledFields.map((field: string) => (
                        <li key={field} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-green-600 dark:bg-green-400" />
                          {field}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {badgeAnalysis.enhancedAnalysis.missingFields.length > 0 && (
                  <div className="space-y-2">
                    <p className="font-semibold text-orange-600 dark:text-orange-400 flex items-center gap-2">
                      <XCircle className="w-4 h-4" />
                      Please Fill In Manually
                    </p>
                    <ul className="space-y-1 text-muted-foreground">
                      {badgeAnalysis.enhancedAnalysis.missingFields.map((field: string) => (
                        <li key={field} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-orange-600 dark:bg-orange-400" />
                          {field.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Officer Information Card */}
            <Card>
              <CardHeader>
                <CardTitle>Officer Information</CardTitle>
                <CardDescription>Provide details about the officer involved</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="officer-name">Officer Name *</Label>
                    <Input
                      id="officer-name"
                      placeholder="Full name"
                      value={officerName}
                      onChange={(e) => setOfficerName(e.target.value)}
                      required
                      data-testid="input-officer-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="badge-number">Badge Number</Label>
                    <Input
                      id="badge-number"
                      placeholder="Optional"
                      value={badgeNumber}
                      onChange={(e) => setBadgeNumber(e.target.value)}
                      data-testid="input-badge-number"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    placeholder="e.g., NYPD, LAPD, Chicago PD"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    data-testid="input-department"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Location Information Card */}
            <Card>
              <CardHeader>
                <CardTitle>Incident Location</CardTitle>
                <CardDescription>Where did the incident occur?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="state">State *</Label>
                    <Select value={state} onValueChange={setState} required>
                      <SelectTrigger id="state" data-testid="select-state">
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        {US_STATES.map(s => (
                          <SelectItem key={s.code} value={s.code}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">City *</Label>
                    <Input
                      id="city"
                      placeholder="City name"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      required
                      data-testid="input-city"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Complaint Details Card */}
            <Card>
              <CardHeader>
                <CardTitle>Complaint Details</CardTitle>
                <CardDescription>Describe what happened</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="complaint-type">Type of Complaint *</Label>
                    <Select value={complaintType} onValueChange={setComplaintType} required>
                      <SelectTrigger id="complaint-type" data-testid="select-complaint-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {COMPLAINT_TYPES.map(type => (
                          <SelectItem key={type} value={type}>
                            {type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="incident-date">Incident Date *</Label>
                    <Input
                      id="incident-date"
                      type="date"
                      value={incidentDate}
                      onChange={(e) => setIncidentDate(e.target.value)}
                      required
                      data-testid="input-incident-date"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide a detailed description of what happened..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={8}
                    required
                    data-testid="textarea-description"
                  />
                  <p className="text-sm text-muted-foreground">
                    Include dates, times, locations, witnesses, and any other relevant details.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Payment Summary Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Payment Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between py-4">
                  <div>
                    <p className="font-medium">Complaint Filing Fee</p>
                    <p className="text-sm text-muted-foreground">One-time payment</p>
                  </div>
                  <div className="text-2xl font-bold">${PRICING.toFixed(2)}</div>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Your complaint will be automatically routed to the appropriate authority (Internal Affairs, Police Chief, County Sheriff, or City Attorney) based on jurisdiction.
                </p>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => window.location.href = "/"}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                size="lg"
                className="flex-1"
                disabled={submitMutation.isPending}
                data-testid="button-submit-complaint"
              >
                {submitMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    Submit & Pay ${PRICING.toFixed(2)}
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
