import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import OfficerInfo from "@/pages/officer";
import ComplaintForm from "@/pages/complaint-form";
import ComplaintDetail from "@/pages/complaint-detail";
import LawsuitForm from "@/pages/lawsuit-form";
import LawsuitDetail from "@/pages/lawsuit-detail";
import Complaints from "@/pages/complaints";
import History from "@/pages/history";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Home} />
      <Route path="/landing" component={Landing} />
      
      {/* Protected routes - only accessible when authenticated */}
      {isAuthenticated && (
        <>
          <Route path="/officer/:id" component={OfficerInfo} />
          <Route path="/complaints" component={Complaints} />
          <Route path="/complaint-form" component={ComplaintForm} />
          <Route path="/complaint/:id" component={ComplaintDetail} />
          <Route path="/lawsuit-form" component={LawsuitForm} />
          <Route path="/lawsuit/:id" component={LawsuitDetail} />
          <Route path="/history" component={History} />
        </>
      )}
      
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
