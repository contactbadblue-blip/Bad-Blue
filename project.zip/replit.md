# Badge Check - Police Complaint & Lawsuit Filing Service

## Overview

Badge Check is a pay-per-use complaint and lawsuit filing service that helps citizens submit formal complaints against police officers and file civil rights lawsuits. The application enables users to:

- Upload badge photos for AI-powered officer identification OR manually enter officer names
- File formal complaints against police officers ($29.99 per submission)
- File civil rights lawsuits with state-specific legal templates ($29.99 per filing)
- Auto-route complaints/lawsuits to the appropriate venue (Internal Affairs, Police Chief, Sheriff, Courts)
- Generate elaborate legal documents with jurisdiction-specific statutes and codes
- Submit complaints with evidence (photos, videos, documents)

The platform operates on a **pay-per-use model** at **$29.99 per submission** (complaint OR lawsuit). We compile officer and department information from public sources but do NOT maintain an officer database - all data is sourced in real-time.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript in SPA (Single Page Application) mode using Vite as the build tool.

**Routing**: Wouter for client-side routing with protected route patterns. Authentication checks redirect unauthenticated users to Replit Auth login endpoint.

**UI Component System**: Radix UI primitives with shadcn/ui component library using the "new-york" style variant. Tailwind CSS for styling with custom design tokens following civic tech design principles (professional, trustworthy, accessible).

**State Management**: TanStack Query (React Query) for server state management with aggressive caching (`staleTime: Infinity`). No global client state management beyond query cache.

**Form Handling**: React Hook Form with Zod schema validation for type-safe form submissions.

**Design System**: Custom Tailwind configuration with neutral base colors, consistent spacing scale (Tailwind units), and Inter/Roboto Mono typography. Design follows Material Design and civic technology UI patterns prioritizing clarity and credibility.

### Backend Architecture

**Runtime**: Node.js with Express.js server framework.

**API Structure**: RESTful API with route organization in `server/routes.ts`. Routes are categorized by feature:
- Auth routes (`/api/auth/*`) - Replit OAuth integration
- Badge lookup routes (`/api/badge-lookups`, `/api/analyze-badge`)
- Complaint/commendation routes
- Petition routes (public and authenticated)
- Subscription/payment routes (Stripe integration)

**Authentication Pattern**: Session-based authentication using Replit OAuth (OpenID Connect). Sessions stored in PostgreSQL with connect-pg-simple. Middleware pattern (`isAuthenticated`) protects routes requiring login.

**File Upload Handling**: Multer middleware for in-memory file uploads (10MB limit) for badge photo analysis.

**API Client Pattern**: Custom fetch wrapper (`apiRequest`) with automatic error handling, credential inclusion, and JSON serialization.

### Data Storage Solutions

**Database**: PostgreSQL via Neon serverless with WebSocket connections.

**ORM**: Drizzle ORM with type-safe schema definitions in `shared/schema.ts`. Schema includes:
- `users` - User accounts with Replit OAuth profile data and Stripe customer ID
- `sessions` - Express session storage (required for Replit Auth)
- `badgeLookups` - History of badge photo analyses (for officer identification)
- `complaints` - Paid complaint submissions with payment tracking, jurisdiction info, and auto-routing data
- `lawsuitFilings` - Paid lawsuit filings with state-specific templates, statutes, and court information

**Schema Design Pattern**: Drizzle schema with Zod validation schemas generated via `drizzle-zod`. All insert/update operations validated against Zod schemas before database interaction.

**Migration Strategy**: Drizzle Kit push for schema migrations. Use `npm run db:push --force` for safe syncing.

### Authentication and Authorization

**Primary Auth**: Replit OAuth (OpenID Connect) integration via `openid-client` and Passport.js strategy. Users authenticated through Replit login flow with profile data (email, name, avatar) stored in database.

**Session Management**: Express sessions with PostgreSQL storage (7-day TTL). Sessions use httpOnly, secure cookies with secret-based signing.

**Authorization Model**: 
- Unauthenticated: Landing page only
- Authenticated: Can access all features but must pay $29.99 per submission (complaint or lawsuit)

**Payment Model**: Pay-per-use at $29.99 per submission. Each complaint or lawsuit requires payment before submission.

### External Dependencies

**Payment Processing**: Stripe integration for pay-per-use payments. 
- Payment Intents for one-time $29.99 charges
- Webhook handler for payment confirmation
- Payment tracking in complaints/lawsuitFilings tables

**AI/ML Service**: OpenAI GPT-5 Vision API for badge photo analysis.
- Analyzes badge images for badge number, department name, and confidence level
- Handles poor quality images (blur, glare, motion) with forensic analysis techniques
- Returns structured JSON with extracted information and confidence ratings
- Lazy initialization pattern to avoid startup errors when API key not configured

**Authentication Service**: Replit OAuth (OpenID Connect) for user authentication.
- Discovery endpoint: `https://replit.com/oidc` (configurable via `ISSUER_URL`)
- Client credentials via `REPL_ID` environment variable
- Memoized OIDC configuration (1-hour cache) for performance

**Image Upload**: react-dropzone for drag-and-drop badge photo uploads with client-side image preview.

**Date Formatting**: date-fns for consistent date formatting across the application.

**Environment Configuration**: 
- `DATABASE_URL` - Required PostgreSQL connection string
- `OPENAI_API_KEY` - Required for badge analysis
- `STRIPE_SECRET_KEY` - Required for payment processing
- `SESSION_SECRET` - Required for session signing
- `REPLIT_DOMAINS` - Required for Replit Auth
- `ISSUER_URL` - Optional OAuth issuer (defaults to Replit)